/**
 * 
 */
package com.cts.rbc.test;

import static junit.framework.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.cts.rbc.enums.FruitNames;
import com.cts.rbc.fruit.Fruit;
import com.cts.rbc.fruit.FruitBasket;

/**
 * @author MohaseenHP
 * Test class for {@link FruitBasket}
 */
public class FruitBasketTest {
	FruitBasket fruitBasket;
	
	@Before
	public void executeBeforeEach()
	{
		 fruitBasket=new FruitBasket();
	}
	
	@Test
	public void testEmptyBasket()
	{
		assertTrue(fruitBasket.getFruitBasket()==null);
	}
	@Test
	public void testItemAddedToBasket()
	{
		Fruit banana=new Fruit(FruitNames.BANANA.name(), 5,5);
		fruitBasket.addItemsToBasket(banana);
		assertTrue(fruitBasket.getFruitBasket().size()==1);		
	}
	
	@Test
	public void testItemRemovedToBasket()
	{
		Fruit banana=new Fruit(FruitNames.BANANA.name(), 5,5);
		Fruit apple=new Fruit(FruitNames.APPLE.name(), 4, 3);
		fruitBasket.addItemsToBasket(banana);
		fruitBasket.addItemsToBasket(apple);
		assertTrue(fruitBasket.getFruitBasket().size()==2);
		fruitBasket.removeItemsFromBasket(apple);
		assertTrue(fruitBasket.getFruitBasket().size()==1);
	}
	
	@Test
	public void testCalculateTotal()
	{
		Fruit banana=new Fruit(FruitNames.BANANA.name(), 5,5);
		fruitBasket.addItemsToBasket(banana);
		assertTrue(fruitBasket.getFruitBasket().size()==1);
		assertTrue(fruitBasket.calculateTotal()==25);
	}
	
}
