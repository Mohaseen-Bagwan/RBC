package com.cts.rbc.enums;

/**
 * 
 */


/**
 * @author MohaseenHP
 *
 */
public enum Fruits {
	BANANA(5),APPLE(4),LEMON(3), ORANGE(6), MANGO(7), GRAPE(6);

    private double price;

    Fruits(double price) {       
        this.price = price;
    }

    public double getFruitName() {
        return this.price;
    }
}
