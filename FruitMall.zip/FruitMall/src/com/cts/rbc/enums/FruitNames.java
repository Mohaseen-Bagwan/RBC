package com.cts.rbc.enums;

/**
 * @author 413940/Mohaseen
 * enum for keeping fruitnames
 */
public enum FruitNames {
	BANANA,
	ORANGE,
	PEACH,
	LEMON,
	APPLE
}
