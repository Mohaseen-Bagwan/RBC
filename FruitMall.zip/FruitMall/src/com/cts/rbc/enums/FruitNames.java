package com.cts.rbc.enums;

/**
 * @author 413940/Mohaseen
 * enum for keeping fruitnames
 */
public enum FruitNames {
	
	BANANA(5),APPLE(4),LEMON(3), ORANGE(6), MANGO(7), GRAPE(6);

    private double price;

    FruitNames(double price) {       
        this.price = price;
    }

    public double getFruitPrice(String name) {
    	for(FruitNames fruit:FruitNames.values())
    	{
    		if(fruit.equals(name))
        return this.price;
    }
    	return 0;
    	}
    
    

}
