package com.cts.rbc.fruit;


/**
 * @author 413940/Mohaseen
 * Entity class representing Fruit object
 * which accepts fruitname and quantity as a parameter while creating object of this class.
 * More attributes like origin and measuring units can be added if required
 */
public final class Fruit {

	private final String fruitName;
	private final float quantity;
	private final double price;
	public Fruit(String fruitName,float quantity,double price){
		this.fruitName=fruitName;
		this.quantity=quantity;
		this.price=price;
	}
	
	/**
	 * @return the fruitName
	 */
	public String getFruitName() {
		return fruitName;
	}
	/**
	 * @return the quantity
	 */
	public float getQuantity() {
		return quantity;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	
}
